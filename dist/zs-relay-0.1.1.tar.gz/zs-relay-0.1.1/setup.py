from setuptools import setup, find_packages

setup(
    name="zs-relay",
    version="0.1.1",
    py_modules=["ZS-Relay-lib"],
)